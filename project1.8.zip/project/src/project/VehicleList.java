package project;

/**
 *
 * @author doanb
 */
public class VehicleList {
    private int V_Id;
    private String Brand;
    private String Model;
    private String Price;

    public VehicleList(int V_Id, String Brand, String Model, String Price) {
        this.V_Id = V_Id;
        this.Brand = Brand;
        this.Model = Model;
        this.Price = Price;
    }

    /**
     * @return the V_Id
     */
    public int getV_Id() {
        return V_Id;
    }

    /**
     * @param V_Id the V_Id to set
     */
    public void setV_Id(int V_Id) {
        this.V_Id = V_Id;
    }

    /**
     * @return the Brand
     */
    public String getBrand() {
        return Brand;
    }

    /**
     * @param Brand the Brand to set
     */
    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    /**
     * @return the Model
     */
    public String getModel() {
        return Model;
    }

    /**
     * @param Model the Model to set
     */
    public void setModel(String Model) {
        this.Model = Model;
    }

    /**
     * @return the Price
     */
    public String getPrice() {
        return Price;
    }

    /**
     * @param Price the Price to set
     */
    public void setPrice(String Price) {
        this.Price = Price;
    }
}
