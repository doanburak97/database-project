package project;

import dba.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLVehicleInformationController implements Initializable {

    @FXML
    private TableView<VehicleList> tableVehicle;
    @FXML
    private TableColumn<?, ?> brand_column;
    @FXML
    private TableColumn<?, ?> model_column;
    @FXML
    private TableColumn<?, ?> price_column;

    @FXML
    private Button btn_back;
    @FXML
    private TextField car_ıd_box;
    @FXML
    private TextField car_brand_box;
    @FXML
    private TextField car_model_box;

    @FXML
    private Button btn_add_vehicle;
    @FXML
    private Button btn_search_vehicle;
    @FXML
    private TableColumn<?, ?> V_Id_column;
    @FXML
    private TextField car_price_box;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = db.projectConnection();
        data = FXCollections.observableArrayList();
        setCellTable();
        loadDataFromDatabase();
    }

    PreparedStatement pst;
    Connection conn;
    dbConnection db = new dbConnection();
    private ResultSet rs = null;
    private ObservableList<VehicleList> data;

    @FXML
    void handleButtonActionAddVehicle(MouseEvent event) {

        try {
            conn = db.projectConnection();
            pst = conn.prepareStatement("insert into VehicleInformation(Brand,Model,Price)values(?,?,?)");

            pst.setString(1, car_brand_box.getText());
            pst.setString(2, car_model_box.getText());
            pst.setString(3, car_price_box.getText());
            pst.execute();

            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("Information");
            a.setHeaderText("Cars information has been added.");
            a.showAndWait();

        } catch (Exception ex) {
            Logger.getLogger(FXMLVehicleInformationController.class.getName()).log(Level.SEVERE, null, ex);
        }
        loadDataFromDatabase();
    }

    @FXML
    private void handleButtonActionTurnBack(MouseEvent event) throws IOException {
        System.out.println("You clicked Turn Back Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLAdminPanel.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }

    private void setCellTable() {

        V_Id_column.setCellValueFactory(new PropertyValueFactory<>("V_Id"));
        brand_column.setCellValueFactory(new PropertyValueFactory<>("Brand"));
        model_column.setCellValueFactory(new PropertyValueFactory<>("Model"));
        price_column.setCellValueFactory(new PropertyValueFactory<>("Price"));

    }

    private void loadDataFromDatabase() {
        data.clear();
        try {
            conn = db.projectConnection();
            pst = conn.prepareStatement("select*from VehicleInformation");
            rs = pst.executeQuery();

            while (rs.next()) {
                data.add(new VehicleList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLVehicleInformationController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableVehicle.setItems(data);
    }

    @FXML
    private void HandleButtonActionSearch(MouseEvent event) throws IOException {

        System.out.println("You clicked search button...");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLSearch.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();

    }

}
