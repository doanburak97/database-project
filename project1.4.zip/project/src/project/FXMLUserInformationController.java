/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import dba.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLUserInformationController implements Initializable {
    @FXML
    private GridPane gridpane;
    @FXML
    private TextField user_box;
    @FXML
    private TextField name_box;
    @FXML
    private TextField surname_box;
    @FXML
    private TextField email_box;
    
    @FXML
    private Button btn_search;
    @FXML
    private Button btn_back;
    
    @FXML
    private TableView<UserInfoLıst> UserInfoTable;
    @FXML
    private TableColumn<?, ?> cid_column;
    @FXML
    private TableColumn<?, ?> name_column;
    @FXML
    private TableColumn<?, ?> surname_column;
    @FXML
    private TableColumn<?, ?> email_column;
    @FXML
    private TableColumn<?, ?> tel_column;
    @FXML
    private TableColumn<?, ?> brand_column;
    @FXML
    private TableColumn<?, ?> model_column;
    @FXML
    private TableColumn<?, ?> pickuplocation_column;
    @FXML
    private TableColumn<?, ?> droplocation_column;
    @FXML
    private TableColumn<?, ?> duration_column;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        conn=db.projectConnection();
        data2=FXCollections.observableArrayList();
        setCellTable();
        loadDataFromDatabase();
    }    
    
    PreparedStatement pst;
    Connection conn;
    dbConnection db = new dbConnection();
    private ResultSet rs=null;
    private ObservableList<UserInfoLıst> data2;
    
    @FXML
    private void handleButtonActionTurnBack(MouseEvent event) throws IOException {
        System.out.println("You clicked Turn Back Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLAdminPanel.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }
    
    private void setCellTable(){
        
        cid_column.setCellValueFactory(new PropertyValueFactory<>("c_id"));
        name_column.setCellValueFactory(new PropertyValueFactory<>("name"));
        surname_column.setCellValueFactory(new PropertyValueFactory<>("surname"));
        email_column.setCellValueFactory(new PropertyValueFactory<>("email"));
        tel_column.setCellValueFactory(new PropertyValueFactory<>("tel"));
        brand_column.setCellValueFactory(new PropertyValueFactory<>("vehicle_brand"));
        model_column.setCellValueFactory(new PropertyValueFactory<>("vehicle_model"));
        pickuplocation_column.setCellValueFactory(new PropertyValueFactory<>("pick_up_car_location"));
        droplocation_column.setCellValueFactory(new PropertyValueFactory<>("drop_car_location"));
        duration_column.setCellValueFactory(new PropertyValueFactory<>("duration"));
        

    }
    
     private void loadDataFromDatabase() {
        try {
            pst = conn.prepareStatement("select * from CustomerInformation");
            rs = pst.executeQuery();

            while (rs.next()) {
                data2.add(new  UserInfoLıst(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
                 
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLCustomerInformationController.class.getName()).log(Level.SEVERE, null, ex);
        }
        UserInfoTable.setItems(data2);
    }
}
