/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author doanb
 */
public class UserInfoLıst {

    public UserInfoLıst(String UserInfoTable) {
        this.UserInfoTable = UserInfoTable;
    }

    private String UserInfoTable;
    private int c_id;
    private String name;
    private String surname;
    private String email;
    private String tel;
    private String vehicle_brand;
    private String vehicle_model;
    private String pick_up_car_location;
    private String drop_car_location;
    private String duration;

    public UserInfoLıst(int c_id, String name, String surname, String email, String tel, String vehicle_brand, String vehicle_model, String pick_up_car_location, String drop_car_location, String duration) {
        this.c_id = c_id;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.tel = tel;
        this.vehicle_brand = vehicle_brand;
        this.vehicle_model = vehicle_model;
        this.pick_up_car_location = pick_up_car_location;
        this.drop_car_location = drop_car_location;
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }

    /**
     * @return the c_id
     */
    public int getC_id() {
        return c_id;
    }

    /**
     * @param c_id the c_id to set
     */
    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the tel
     */
    public String getTel() {
        return tel;
    }

    /**
     * @param tel the tel to set
     */
    public void setTel(String tel) {
        this.tel = tel;
    }

    /**
     * @return the vehicle_brand
     */
    public String getVehicle_brand() {
        return vehicle_brand;
    }

    /**
     * @param vehicle_brand the vehicle_brand to set
     */
    public void setVehicle_brand(String vehicle_brand) {
        this.vehicle_brand = vehicle_brand;
    }

    /**
     * @return the vehicle_model
     */
    public String getVehicle_model() {
        return vehicle_model;
    }

    /**
     * @param vehicle_model the vehicle_model to set
     */
    public void setVehicle_model(String vehicle_model) {
        this.vehicle_model = vehicle_model;
    }

    /**
     * @return the pick_up_car_location
     */
    public String getPick_up_car_location() {
        return pick_up_car_location;
    }

    /**
     * @param pick_up_car_location the pick_up_car_location to set
     */
    public void setPick_up_car_location(String pick_up_car_location) {
        this.pick_up_car_location = pick_up_car_location;
    }

    /**
     * @return the drop_car_location
     */
    public String getDrop_car_location() {
        return drop_car_location;
    }

    /**
     * @param drop_car_location the drop_car_location to set
     */
    public void setDrop_car_location(String drop_car_location) {
        this.drop_car_location = drop_car_location;
    }

    /**
     * @return the UserInfoTable
     */
    public String getUserInfoTable() {
        return UserInfoTable;
    }

}
