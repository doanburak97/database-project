/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database2project;

/**
 *
 * @author doanb
 */
public class PlayerInfoList {

    public PlayerInfoList(String userpanel_playertable) {
        this.userpanel_playertable = userpanel_playertable;
    }

    public PlayerInfoList(int playerNo, String name, String surname, int age, String position, String team, int price) {

        this.playerNo = playerNo;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.position = position;
        this.team = team;
        this.price = price;
    }

    private String userpanel_playertable;
    private int playerNo;
    private String name;
    private String surname;
    private int age;
    private String position;
    private String team;
    private int price;

    /**
     * @return the userpanel_playertable
     */
    public String getUserpanel_playertable() {
        return userpanel_playertable;
    }

    /**
     * @param userpanel_playertable the userpanel_playertable to set
     */
    public void setUserpanel_playertable(String userpanel_playertable) {
        this.userpanel_playertable = userpanel_playertable;
    }

    /**
     * @return the playerNo
     */
    public int getPlayerNo() {
        return playerNo;
    }

    /**
     * @param playerNo the playerNo to set
     */
    public void setPlayerNo(int playerNo) {
        this.playerNo = playerNo;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * @return the position
     */
    public String getPosition() {
        return position;
    }

    /**
     * @param position the position to set
     */
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * @return the team
     */
    public String getTeam() {
        return team;
    }

    /**
     * @param team the team to set
     */
    public void setTeam(String team) {
        this.team = team;
    }

    /**
     * @return the price
     */
    public int getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }
}
