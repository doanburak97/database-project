package database2project;

import dba.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLUserPanelsController implements Initializable {

    @FXML
    private ComboBox<?> age_combobox;
    @FXML
    private ComboBox<?> position_combobox;
    @FXML
    private ComboBox<?> price_combobox;

    //buttons----------
    @FXML
    private Button age_list_button;
    @FXML
    private Button position_list_button;
    @FXML
    private Button price_list_button;
    @FXML
    private Button btn_clear;
    @FXML
    private Button btn_back;

    //columns---------
    @FXML
    private TableView<PlayerInfoList> userpanel_playertable;
    @FXML
    private TableColumn<?, ?> clm_playerNo;
    @FXML
    private TableColumn<?, ?> clm_name;
    @FXML
    private TableColumn<?, ?> clm_surname;
    @FXML
    private TableColumn<?, ?> clm_age;
    @FXML
    private TableColumn<?, ?> clm_position;
    @FXML
    private TableColumn<?, ?> clm_team;
    @FXML
    private TableColumn<?, ?> clm_price;

    CallableStatement cs;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = db.project2Connection();
        data3 = FXCollections.observableArrayList();
        setCellTable();
        loadDataFromDatabase();
    }

    PreparedStatement pst;
    Connection conn;
    dbConnection db = new dbConnection();
    private ResultSet rs = null;
    private ObservableList<PlayerInfoList> data3;

    private void setCellTable() {
        clm_playerNo.setCellValueFactory(new PropertyValueFactory<>("playerNo"));
        clm_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        clm_surname.setCellValueFactory(new PropertyValueFactory<>("surname"));
        clm_age.setCellValueFactory(new PropertyValueFactory<>("age"));
        clm_position.setCellValueFactory(new PropertyValueFactory<>("position"));
        clm_team.setCellValueFactory(new PropertyValueFactory<>("team"));
        clm_price.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    private void loadDataFromDatabase() {
        try {
            pst = conn.prepareStatement("select * from players");
            rs = pst.executeQuery();

            while (rs.next()) {
                data3.add(new PlayerInfoList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getInt(7)));

            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLUserPanelsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        userpanel_playertable.setItems(data3);
    }

    @FXML
    private void ButtonTurnBack(MouseEvent event) throws IOException {
        System.out.println("You clicked Turn Back Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLDocumentDb2.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }
}
