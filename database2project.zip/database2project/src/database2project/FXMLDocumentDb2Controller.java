/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database2project;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author doanb
 */
public class FXMLDocumentDb2Controller implements Initializable {

    @FXML
    private TextField txt_admin;
    @FXML
    private TextField txt_user;
    @FXML
    private PasswordField psw_admin;
    @FXML
    private PasswordField psw_user;
    @FXML
    private Button btn_admin;
    @FXML
    private Button btn_user;

    @FXML
    private void ButtonAdminPanel(MouseEvent event) throws IOException {
        String admin = "admin";
        String password = "admin";

        String value1 = txt_admin.getText();
        String value2 = psw_admin.getText();

        if (!(value1.equals(admin)) || !(value2.equals(password))) {
            Alert a = new Alert(AlertType.INFORMATION);
            a.setHeaderText("Admin name or password wrong!!!");
            a.setTitle("Error Found");
            a.showAndWait();
        } else {
            System.out.println("You clicked Admin Login Button..");
            Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLAdminPanels.fxml"));
            Scene userscreen_page_scene = new Scene(userscreen_page_parent);
            Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.hide();
            app_stage.setScene(userscreen_page_scene);
            app_stage.show();
        }
    }
    
    @FXML
    private void ButtonUserPanel(MouseEvent event) throws IOException {
        String user = "user";
        String userpassword = "user";

        String value3 = txt_user.getText();
        String value4 = psw_user.getText();

        if (!(value3.equals(user)) || !(value4.equals(userpassword))) {
            Alert a = new Alert(AlertType.INFORMATION);
            a.setHeaderText("User name or password wrong!!!");
            a.setTitle("Error Found");
            a.showAndWait();
        } else {
            System.out.println("You clicked User Login Button..");
            Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLUserPanels.fxml"));
            Scene userscreen_page_scene = new Scene(userscreen_page_parent);
            Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.hide();
            app_stage.setScene(userscreen_page_scene);
            app_stage.show();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
