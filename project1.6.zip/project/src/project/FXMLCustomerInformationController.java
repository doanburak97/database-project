/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import dba.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLCustomerInformationController implements Initializable {

    @FXML
    private TextField c_name_box;
    @FXML
    private TextField c_surname_box;
    @FXML
    private TextField c_email_box;
    @FXML
    private TextField c_tel_box;
    
    @FXML
    private TextField v_model_box;
    @FXML
    private TextField v_pickup_box;
    @FXML
    private TextField v_drop_box;
    @FXML
    private TextField v_duration_box;
    @FXML
    private Button btn_submit;
    @FXML
    private Button btn_back;
    private ComboBox<String> vehicle_brand_combobox;
    @FXML
    private TextField v_brand_box;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
    }

    PreparedStatement pst;
    Connection conn;
    dbConnection db = new dbConnection();
    CallableStatement cs;
    @FXML
    private void handleButtonActionCustomerInformation(MouseEvent event) {

        try {
            conn = db.projectConnection();
            pst = conn.prepareStatement("insert into CustomerInformation"
                    + "(name,surname,email,tel,vehicle_brand,vehicle_model,pick_up_car_location,drop_car_location,duration)"
                    + "values(?,?,?,?,?,?,?,?,?)");

            pst.setString(1, c_name_box.getText());
            pst.setString(2, c_surname_box.getText());
            pst.setString(3, c_email_box.getText());
            pst.setString(4, c_tel_box.getText());
            pst.setString(5, v_brand_box.getText());
            pst.setString(6, v_model_box.getText());
            pst.setString(7, v_pickup_box.getText());
            pst.setString(8, v_drop_box.getText());
            pst.setString(9, v_duration_box.getText());
            pst.execute();

            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("Information");
            a.setHeaderText("Customer Information has been created.");
            a.showAndWait();

        } catch (Exception ex) {
            Logger.getLogger(FXMLCustomerInformationController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void handleButtonActionTurnBack(MouseEvent event) throws IOException {
        System.out.println("You clicked Turn Back Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }
    ObservableList options = FXCollections.observableArrayList();

    void fillComboBox(ComboBox cmb) {
       
        try {
            String SQL = "SELECT * from dbo.get_vehicle_brand";
            conn = db.projectConnection();
            ResultSet rs = conn.createStatement().executeQuery(SQL);
            options.clear();
            while (rs.next()) {
                options.add(rs.getString("brand"));
            }
            rs.close();
            cmb.setItems(options);
           
        } catch (SQLException ex) {
            Logger.getLogger(FXMLCustomerInformationController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    void fillComboBox2(ComboBox cmb) {
       
        try {
            String SQL = "SELECT * from dbo.get_vehicle_model(?)";
            conn = db.projectConnection();
            cs = conn.prepareCall(SQL);
            cs.setString(1,vehicle_brand_combobox.getValue());
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                options.add(rs.getString("model"));
            }
            rs.close();
            cmb.setItems(options);

        } catch (SQLException ex) {
            Logger.getLogger(FXMLCustomerInformationController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

}
