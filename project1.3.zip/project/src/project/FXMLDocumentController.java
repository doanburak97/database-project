/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author doanb
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private TextField admin_email_box;
    @FXML
    private PasswordField admin_password_box;
    @FXML
    private Button btn_LoginAdmin;
    @FXML
    private TextField user_email_box;
    @FXML
    private PasswordField user_password_box;
    @FXML
    private Button btn_loginCustomer;
    @FXML
    private Label lbl_register;
    @FXML
    private Button btn_rentacar;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void handleButtonActionAdmin(MouseEvent event) throws IOException {
        String admin = "admin";
        String password = "admin";

        String value1 = admin_email_box.getText();
        String value2 = admin_password_box.getText();

        if (!(value1.equals(admin)) || !(value2.equals(password))) {
            Alert a = new Alert(AlertType.INFORMATION);
            a.setHeaderText("Kullanıcı Adı Veya Şifresi Yanlış!");
            a.setTitle("Error Found");
            a.showAndWait();
        } else {

            System.out.println("You clicked Admin Login Button");
            Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLAdminPanel.fxml"));
            Scene userscreen_page_scene = new Scene(userscreen_page_parent);
            Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.hide();
            app_stage.setScene(userscreen_page_scene);
            app_stage.show();

        }
    }

    @FXML
    private void handleButtonActionRentACar(MouseEvent event) throws IOException {
        System.out.println("You clicked Rent A Car Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLCustomerInformation.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }
}
