/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import dbConnection.dbConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLRegisterPanelController implements Initializable {

    @FXML
    private TextField user_name_box;

    @FXML
    private TextField user_surname_box;

    @FXML
    private TextField user_tel_box;

    @FXML
    private TextField user_email_box;

    @FXML
    private TextField user_password_box;

    @FXML
    private Button btn_create_account;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    PreparedStatement pst;
    Connection conn;
    dbConnection db = new dbConnection();

    @FXML
    void handleButtonActionCreateAccount(MouseEvent even) {

        try {
            conn = db.projectConnection();
            pst = conn.prepareStatement("insert into Customers(name,surname,tel,email,password)values(?,?,?,?,?)");

            pst.setString(1, user_name_box.getText());
            pst.setString(2, user_surname_box.getText());
            pst.setString(3, user_tel_box.getText());
            pst.setString(4, user_email_box.getText());
            pst.setString(5, user_password_box.getText());
            pst.execute();
            
            Alert a = new Alert(AlertType.INFORMATION);
            a.setTitle("My Title");
            a.setHeaderText("My Header Text");
            a.showAndWait();
            
        } catch (Exception ex) {
            Logger.getLogger(FXMLRegisterPanelController.class.getName()).log(Level.SEVERE, null, ex);
        } 

    }
}
