/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project2;

/**
 *
 * @author doanb
 */
public class UserInfoList {

    /**
     *
     * @param UserInfoTable2
     */
    public UserInfoList(String UserInfoTable2) {
        this.UserInfoTable2 = UserInfoTable2;
    }

    private String UserInfoTable2;
    private int c_id;
    private String name;
    private String surname;
    private String email;
    private String tel;
    private int v_id;
    private String brand;
    private String model;
    private String price;
    private int l_id;
    private String pick_up_location;
    private String drop_car_location;

    public UserInfoList(int c_id, String name, String surname, String email, String tel, int v_id, String brand, String model, String price, int l_id, String pick_up_location, String drop_car_location) {
        this.c_id = c_id;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.tel = tel;
        this.v_id = v_id;
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.l_id = l_id;
        this.pick_up_location = pick_up_location;
        this.drop_car_location = drop_car_location;

    }

    public String getUserInfoTable2() {
        return UserInfoTable2;
    }

    /**
     *
     * @param UserInfoTable2
     */
    public void setUserInfoTable(String UserInfoTable2) {
        this.setUserInfoTable2(UserInfoTable2);
    }

    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public int getV_id() {
        return v_id;
    }

    public void setV_id(int v_id) {
        this.v_id = v_id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getL_id() {
        return l_id;
    }

    public void setL_id(int l_id) {
        this.l_id = l_id;
    }

    public String getPick_up_location() {
        return pick_up_location;
    }

    public void setPick_up_location(String pick_up_location) {
        this.pick_up_location = pick_up_location;
    }

    public String getDrop_car_location() {
        return drop_car_location;
    }

    public void setDrop_car_location(String drop_car_location) {
        this.drop_car_location = drop_car_location;
    }

    /**
     * @param UserInfoTable2 the UserInfoTable2 to set
     */
    public void setUserInfoTable2(String UserInfoTable2) {
        this.UserInfoTable2 = UserInfoTable2;
    }

}
