/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project2;

import dba.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLSearchController implements Initializable {

    @FXML
    private TableView<SearchList> SearchTable;
    @FXML
    private TableColumn<?, ?> v_ıd_column;
    @FXML
    private TableColumn<?, ?> brand_column;
    @FXML
    private TableColumn<?, ?> model_column;
    @FXML
    private TableColumn<?, ?> price_column;
    @FXML
    private Button btn_back;
    @FXML
    private TextField txt_search;
    @FXML
    private Button btn_search;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = db.project2Connection();
        data = FXCollections.observableArrayList();
        setCellTable();

    }

    PreparedStatement pst;
    Connection conn;
    dbConnection db = new dbConnection();
    private ResultSet rs = null;
    private ObservableList<SearchList> data;

    @FXML
    private void handleButtonActionTurnBack(MouseEvent event) throws IOException {
        System.out.println("You clicked Turn Back Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLVehicleInformation.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }

    private void setCellTable() {

        v_ıd_column.setCellValueFactory(new PropertyValueFactory<>("V_Id"));
        brand_column.setCellValueFactory(new PropertyValueFactory<>("Brand"));
        model_column.setCellValueFactory(new PropertyValueFactory<>("Model"));
        price_column.setCellValueFactory(new PropertyValueFactory<>("Price"));

    }

    @FXML
    private void handleButtonActionSearch(MouseEvent event) throws IOException {
        data.clear();
        String value1 = txt_search.getText();

        if (value1.equals("Mercedes")) {
            try {
                conn = db.project2Connection();
                pst = conn.prepareStatement("select*from dbo.Mercedes");
                rs = pst.executeQuery();

                while (rs.next()) {
                    data.add(new SearchList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
                }
            } catch (SQLException ex) {
                Logger.getLogger(FXMLVehicleInformationController.class.getName()).log(Level.SEVERE, null, ex);
            }
            SearchTable.setItems(data);

        } else if (value1.equals("BMW")) {
            try {
                conn = db.project2Connection();
                pst = conn.prepareStatement("select*from dbo.BMW");
                rs = pst.executeQuery();

                while (rs.next()) {
                    data.add(new SearchList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
                }
            } catch (SQLException ex) {
                Logger.getLogger(FXMLVehicleInformationController.class.getName()).log(Level.SEVERE, null, ex);
            }
            SearchTable.setItems(data);
            
        } else if (value1.equals("Volkswagen")) {
            try {
                conn = db.project2Connection();
                pst = conn.prepareStatement("select*from dbo.Volkswagen");
                rs = pst.executeQuery();

                while (rs.next()) {
                    data.add(new SearchList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
                }
            } catch (SQLException ex) {
                Logger.getLogger(FXMLVehicleInformationController.class.getName()).log(Level.SEVERE, null, ex);
            }
            SearchTable.setItems(data);
            
        } else if (value1.equals("Fiat")) {
            try {
                conn = db.project2Connection();
                pst = conn.prepareStatement("select*from dbo.Fiat");
                rs = pst.executeQuery();

                while (rs.next()) {
                    data.add(new SearchList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
                }
            } catch (SQLException ex) {
                Logger.getLogger(FXMLVehicleInformationController.class.getName()).log(Level.SEVERE, null, ex);
            }
            SearchTable.setItems(data);
            
        } else if (value1.equals("Seat")) {
            try {
                conn = db.project2Connection();
                pst = conn.prepareStatement("select*from dbo.Seat");
                rs = pst.executeQuery();

                while (rs.next()) {
                    data.add(new SearchList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
                }
            } catch (SQLException ex) {
                Logger.getLogger(FXMLVehicleInformationController.class.getName()).log(Level.SEVERE, null, ex);
            }
            SearchTable.setItems(data);
            
        } else {
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("Information");
            a.setHeaderText("You entered wrong value.");
            a.showAndWait();
        }
    }

}
