/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project2;

import dba.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


public class FXMLUserInformationController implements Initializable {

    @FXML
    private Button btn_search;
    @FXML
    private Button btn_back;
    @FXML
    private TableView<UserInfoList> UserInfoTable2;
    @FXML
    private TableColumn<?, ?> cid_column;
    @FXML
    private TableColumn<?, ?> name_column;
    @FXML
    private TableColumn<?, ?> surname_column;
    @FXML
    private TableColumn<?, ?> email_column;
    @FXML
    private TableColumn<?, ?> tel_column;
    @FXML
    private TableColumn<?, ?> v_id_column;
    @FXML
    private TableColumn<?, ?> brand_column;
    @FXML
    private TableColumn<?, ?> model_column;
    @FXML
    private TableColumn<?, ?> price_column;
    @FXML
    private TableColumn<?, ?> l_id;
    @FXML
    private TableColumn<?, ?> pick_up_location_column;
    @FXML
    private TableColumn<?, ?> drop_car_location_column;

    CallableStatement cs;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        con = db.project2Connection();
        data3 = FXCollections.observableArrayList();
        setCellTable();
        loadDataFromDatabase();
    }

    PreparedStatement pst;
    Connection con;
    dbConnection db = new dbConnection();
    private ResultSet rs = null;
    private ObservableList<UserInfoList> data3;

    @FXML
    private void handleButtonActionTurnBack(MouseEvent event) throws IOException {
        System.out.println("You clicked Turn Back Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLAdminPanel.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }

    private void setCellTable() {

        cid_column.setCellValueFactory(new PropertyValueFactory<>("c_id"));
        name_column.setCellValueFactory(new PropertyValueFactory<>("name"));
        surname_column.setCellValueFactory(new PropertyValueFactory<>("surname"));
        email_column.setCellValueFactory(new PropertyValueFactory<>("email"));
        tel_column.setCellValueFactory(new PropertyValueFactory<>("tel"));
        v_id_column.setCellValueFactory(new PropertyValueFactory<>("v_id"));
        brand_column.setCellValueFactory(new PropertyValueFactory<>("brand"));
        model_column.setCellValueFactory(new PropertyValueFactory<>("model"));
        price_column.setCellValueFactory(new PropertyValueFactory<>("price"));
        l_id.setCellValueFactory(new PropertyValueFactory<>("l_id"));
        
        pick_up_location_column.setCellValueFactory(new PropertyValueFactory<>("pick_up_location"));
        drop_car_location_column.setCellValueFactory(new PropertyValueFactory<>("drop_car_location"));

    }

    private void loadDataFromDatabase() {
        try {
            pst = con.prepareStatement("select * from dbo.show_all_information");
            rs = pst.executeQuery();

            while (rs.next()) {
                data3.add(new UserInfoList(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)
                        , rs.getString(5), rs.getInt(6), rs.getString(7), rs.getString(8), rs.getString(9)
                        , rs.getInt(10), rs.getString(11), rs.getString(12)));

            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLUserInformationController.class.getName()).log(Level.SEVERE, null, ex);
        }
        UserInfoTable2.setItems(data3);
    }

    @FXML
    private void tableClick(MouseEvent event) {
    }

}
