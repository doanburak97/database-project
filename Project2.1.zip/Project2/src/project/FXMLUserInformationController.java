/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLUserInformationController implements Initializable {
    @FXML
    private Button btn_search;
    @FXML
    private Button btn_back;
    @FXML
    private TableView<?> UserInfoTable;
    @FXML
    private TableColumn<?, ?> cid_column;
    @FXML
    private TableColumn<?, ?> name_column;
    @FXML
    private TableColumn<?, ?> surname_column;
    @FXML
    private TableColumn<?, ?> email_column;
    @FXML
    private TableColumn<?, ?> tel_column;
    @FXML
    private TableColumn<?, ?> v_id_column;
    @FXML
    private TableColumn<?, ?> brand_column;
    @FXML
    private TableColumn<?, ?> model_column;
    @FXML
    private TableColumn<?, ?> price_column;
    @FXML
    private TableColumn<?, ?> l_id;
    @FXML
    private TableColumn<?, ?> pick_up_location_column;
    @FXML
    private TableColumn<?, ?> drop_car_location_column;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleButtonActionTurnBack(MouseEvent event) {
    }

    @FXML
    private void tableClick(MouseEvent event) {
    }
    
}
