/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project2;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author doanb
 */
public class FXMLAdminPanelController implements Initializable {

    @FXML
    private Button btn_vehicle_info;
    @FXML
    private Button btn_user_info;
    @FXML
    private Button btn_turn_back;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void handleButtonActionVehicleInfo(MouseEvent event) throws IOException {
        System.out.println("You clicked Vehicle Information Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLVehicleInformation.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }

    @FXML
    private void handleButtonActionUserInfo(MouseEvent event) throws IOException {
        System.out.println("You clicked User Information Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLUserInformation.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }

    @FXML
    private void handleButtonActionTurnBack(MouseEvent event) throws IOException {
        System.out.println("You clicked Turn Back Button");
        Parent userscreen_page_parent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene userscreen_page_scene = new Scene(userscreen_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.hide();
        app_stage.setScene(userscreen_page_scene);
        app_stage.show();
    }
}
